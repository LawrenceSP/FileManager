package com.file.FileManager.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.file.FileManager.dto.FileDetailsEntity;

@Repository
public class FileManagerDaoImpl {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public void saveFile(FileDetailsEntity fileDetails) {
		
	}
	
	public void moveFile(String existingPath, String newPath) {
		
	}
	
	public List<FileDetailsEntity> getFileDetails(int fileId) {
	
		@SuppressWarnings("deprecation")
		List<FileDetailsEntity> fileDetailsBean = jdbcTemplate.query("select file_name, file_path from file_details where file_id=?",
				new Object[] {fileId}, new RowMapper<FileDetailsEntity>() {

					public FileDetailsEntity mapRow(ResultSet result, int arg1) throws SQLException {
						FileDetailsEntity fileDetails = new FileDetailsEntity();
						fileDetails.setFileName(result.getString("file_name"));
						fileDetails.setFilePath(result.getString("file_path"));
						return fileDetails;
					}
			
		});
		
		return fileDetailsBean;
		
	}
}
