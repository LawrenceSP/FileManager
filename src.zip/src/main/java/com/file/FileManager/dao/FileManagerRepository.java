package com.file.FileManager.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.file.FileManager.dto.FileDetailsEntity;

@Repository
public interface FileManagerRepository extends JpaRepository<FileDetailsEntity, Long>{


}
