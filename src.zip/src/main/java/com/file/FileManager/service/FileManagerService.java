package com.file.FileManager.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystemException;
import java.nio.file.Path;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.file.FileManager.dao.FileManagerRepository;
import com.file.FileManager.dto.FileDetailsEntity;

@Service
public class FileManagerService {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private FileManagerRepository fileManagerRepo;
	
	public boolean moveFile(String existingPath, String newPath) {
		Path result = null;
		boolean isFileMoved = false;
		
		
		File fileToMove = new File(existingPath);
	    File targetFile = new File(newPath);

	    try {
	    	if(targetFile.canWrite())
			{
	    		com.google.common.io.Files.move(fileToMove, targetFile);
	    		isFileMoved = true;
			}
			
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
//		File oldPath = new File(existingPath);
//		if(oldPath.exists()) {
//			 try {
//		         result = Files.move(Paths.get(existingPath), Paths.get(newPath));
//		      } catch (IOException e) {
//		    	  logger.error("Exception while moving file: " + e.getMessage());
//		      }
//		}
//		if(result != null) {
//			logger.info("File moved successfully.");
//			isFileMoved = true;
//			// Also update the path into table
//	      }
		return isFileMoved;
	}
	
	public boolean renameFile(String existingPath, String fileName) throws FileSystemException {
		File fileToMove = new File(existingPath);
	    boolean isMoved = fileToMove.renameTo(new File(fileName));
	    // Also update the path into table
	    if (!isMoved) {
	        throw new FileSystemException(fileName);
	    }
		return isMoved;
		
	}
	
	public List<FileDetailsEntity> getAllFileDetails(){
			return null; // fileManagerRepo.getAllFileDetails();
		
	}
}
